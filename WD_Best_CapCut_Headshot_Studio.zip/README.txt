WD BEST CAPCUT — HEADSHOT STUDIO ADD-ON

1. Open headshot-studio.html in Chrome (or upload it to GitHub Pages).
2. Load a Free Fire gameplay video.
3. Mark exact headshot moments manually, or use Scan action peaks as suggestions.
4. Upload a song and analyse approximate beats, or create and download an original instrumental beat.
5. Build an auto or manual cut plan, snap moments to beats, and copy the timestamps into your main editor.

IMPORTANT:
- Visual scan estimates scene/action changes. It cannot verify headshots.
- This prototype creates beat files and cut plans; it does not yet render a finished montage.
- The local beat generator creates instrumental audio, not sung vocals.
